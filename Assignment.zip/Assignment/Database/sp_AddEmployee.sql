CREATE PROCEDURE sp_AddEmployee
(
	@EmpCode varchar(10),
	@EmpName varchar(100),
	@EmpDept varchar(20),
	@EmpGender varchar(1),
	@EmpDOB varchar(20),
	@EmpDOJ varchar(20),
	@EmpPrevExp int,
	@EmpSalary int,
	@EmpAddress varchar(500)
)
AS
BEGIN

 INSERT INTO EmployeeDetails (Emp_Code, Emp_Name, Emp_Dept, Emp_Gender, Emp_DOB, Emp_DOJ, Emp_PrevExp, Emp_Salary, Emp_Address )
 VALUES (@EmpCode, @EmpName, @EmpDept, @EmpGender,@EmpDOB, @EmpDOJ, @EmpPrevExp, @EmpSalary, @EmpAddress)   

END
