CREATE PROCEDURE sp_UpdateEmployee
(
	@Emp_Id int,
	@EmpCode varchar(10),
	@EmpName varchar(100),
	@EmpDept varchar(20),
	@EmpGender varchar(1),
	@EmpDOB varchar(20),
	@EmpDOJ varchar(20),
	@EmpPrevExp int,
	@EmpSalary int,
	@EmpAddress varchar(500)
)
AS
BEGIN

 update EmployeeDetails set Emp_Code = @EmpCode, Emp_Name = @EmpName,
                            Emp_Dept = @EmpDept, Emp_Gender =  @EmpGender,
							Emp_DOB = @EmpDOB, Emp_DOJ = @EmpDOJ,
							Emp_PrevExp = @EmpPrevExp, Emp_Salary = @EmpSalary, 
							Emp_Address = @EmpAddress WHERE Emp_Id = @Emp_Id
 

END