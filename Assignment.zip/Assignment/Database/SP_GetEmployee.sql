CREATE PROCEDURE SP_GetEmployee
(
	@EmpId int
)
AS
BEGIN

	SELECT Emp_Id,Emp_Code,Emp_Name,Emp_Dept,
	CASE WHEN Emp_Gender = 'M' THEN 'Male' ELSE 'Female' END AS Emp_Gender,
	Emp_DOB,Emp_DOJ,Emp_PrevExp,Emp_Salary,Emp_Address FROM EmployeeDetails 
	WHERE Emp_Id = @EmpId or 0 = @EmpId

END