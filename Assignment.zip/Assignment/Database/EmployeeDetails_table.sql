USE [Employee]
GO

/****** Object:  Table [dbo].[EmployeeDetails]    Script Date: 07-04-2022 20:38:00 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[EmployeeDetails](
	[Emp_Id] [int] IDENTITY(1,1) NOT NULL,
	[Emp_Code] [varchar](10) NULL,
	[Emp_Name] [varchar](100) NULL,
	[Emp_Dept] [varchar](20) NULL,
	[Emp_Gender] [varchar](1) NULL,
	[Emp_DOB] [varchar](20) NULL,
	[Emp_DOJ] [varchar](20) NULL,
	[Emp_PrevExp] [int] NULL,
	[Emp_Salary] [int] NULL,
	[Emp_Address] [varchar](500) NULL,
 CONSTRAINT [PK_EmployeeDetails] PRIMARY KEY CLUSTERED 
(
	[Emp_Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


