﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;




namespace AssignmentNewel
{
    public partial class _Default : Page
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EmpConnection"].ConnectionString);
        string gender;
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {

                binddata();

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        protected void btsubmit_Click(object sender, EventArgs e)
        {
            conn.Open();

            SqlCommand Cmd = new SqlCommand();
            Cmd.Connection = conn;
            Cmd.CommandType = CommandType.StoredProcedure;
            if (btsubmit.Text == "Submit")
            {
                Cmd.CommandText = "sp_AddEmployee";
                Cmd.Parameters.AddWithValue("@EmpCode", txtEmpCode.Text);
                Cmd.Parameters.AddWithValue("@EmpName", txtName.Text);
                Cmd.Parameters.AddWithValue("@EmpDept", ddlDepartment.SelectedValue);
                if (rbMale.Checked == true)
                {
                    Cmd.Parameters.AddWithValue("@EmpGender", "M");
                }
                else
                {
                    Cmd.Parameters.AddWithValue("@EmpGender", "F");

                }
                Cmd.Parameters.AddWithValue("@EmpDOB", txtDOB.Text);
                Cmd.Parameters.AddWithValue("@EmpDOJ", txtJoinDate.Text);
                Cmd.Parameters.AddWithValue("@EmpPrevExp", txtPrevexp.Text);
                Cmd.Parameters.AddWithValue("@EmpSalary", txtsalary.Text);
                Cmd.Parameters.AddWithValue("@EmpAddress", txtaddress.Text);

            }
            else

            {

                Cmd.CommandText = "sp_UpdateEmployee";
                Cmd.Parameters.AddWithValue("@Emp_Id", (int)Session["EmpId"]);

                Cmd.Parameters.AddWithValue("@EmpCode", txtEmpCode.Text);
                Cmd.Parameters.AddWithValue("@EmpName", txtName.Text);
                Cmd.Parameters.AddWithValue("@EmpDept", ddlDepartment.SelectedValue);
                if (rbMale.Checked == true)
                {
                    Cmd.Parameters.AddWithValue("@EmpGender", "M");
                }
                else
                {
                    Cmd.Parameters.AddWithValue("@EmpGender", "F");

                }

                Cmd.Parameters.AddWithValue("@EmpDOB", txtDOB.Text);
                Cmd.Parameters.AddWithValue("@EmpDOJ", txtJoinDate.Text);
                Cmd.Parameters.AddWithValue("@EmpPrevExp", txtPrevexp.Text);
                Cmd.Parameters.AddWithValue("@EmpSalary", txtsalary.Text);
                Cmd.Parameters.AddWithValue("@EmpAddress", txtaddress.Text);

            }
            Cmd.ExecuteNonQuery();
            conn.Close();
            clearall();

            binddata();

        }

        private void clearall()
        {

            txtEmpCode.Text = "";
            txtName.Text = "";
            //ddlDepartment. = "";
            txtDOB.Text = "";
            txtJoinDate.Text = "";
            txtPrevexp.Text = "";
            txtsalary.Text = "";
            txtaddress.Text = "";
            btsubmit.Text = "Submit";


        }
        private void binddata()
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter adp = new SqlDataAdapter();
            int empID = 0;

            DataSet ds = new DataSet();
            cmd.Connection = conn;

            cmd.CommandText = "SP_GetEmployee";

            cmd.Parameters.Add(new SqlParameter("@EmpId", empID));

            cmd.CommandType = CommandType.StoredProcedure;


            adp.SelectCommand = cmd;
            adp.Fill(ds);

            conn.Close();

            if (ds.Tables[0].Rows.Count > 0)
            {
                grdEmp.DataSource = ds.Tables[0];
                grdEmp.DataBind();
            }

        }

        protected void btcancel_Click(object sender, EventArgs e)
        {
            clearall();
        }

        protected void lnkEdit_Click(object sender, EventArgs e)
        {
            int rowIndex = ((sender as LinkButton).NamingContainer as GridViewRow).RowIndex;

            //Get the value of column from the DataKeys using the RowIndex.

            int id = Convert.ToInt32(grdEmp.DataKeys[rowIndex].Values[0]);
            Session["EmpId"] = id;

            conn.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter adp = new SqlDataAdapter();


            DataSet ds = new DataSet();
            cmd.Connection = conn;

            cmd.CommandText = "SP_GetEmployee";

            cmd.Parameters.Add(new SqlParameter("@EmpId", id));

            cmd.CommandType = CommandType.StoredProcedure;


            adp.SelectCommand = cmd;
            adp.Fill(ds);

            conn.Close();

            if (ds.Tables[0].Rows.Count > 0)
            {
                txtEmpCode.Text = ds.Tables[0].Rows[0]["Emp_Code"].ToString();
                txtName.Text = ds.Tables[0].Rows[0]["Emp_Name"].ToString();
                ddlDepartment.SelectedValue = ds.Tables[0].Rows[0]["Emp_Dept"].ToString();
                txtDOB.Text = ds.Tables[0].Rows[0]["Emp_DOB"].ToString();
                txtJoinDate.Text = ds.Tables[0].Rows[0]["Emp_DOJ"].ToString();
                txtPrevexp.Text = ds.Tables[0].Rows[0]["Emp_PrevExp"].ToString();
                txtsalary.Text = ds.Tables[0].Rows[0]["Emp_Salary"].ToString();
                txtaddress.Text = ds.Tables[0].Rows[0]["Emp_Address"].ToString();

                btsubmit.Text = "Update";
            }

        }




        protected void rbMale_CheckedChanged(object sender, EventArgs e)
        {
            if (rbMale.Checked == true)
            {
                rbFemale.Checked = false;
            }



        }


        protected void rbFemale_CheckedChanged(object sender, EventArgs e)
        {
            if (rbFemale.Checked == true)
            {
                rbMale.Checked = false;
            }


        }


    }
}




